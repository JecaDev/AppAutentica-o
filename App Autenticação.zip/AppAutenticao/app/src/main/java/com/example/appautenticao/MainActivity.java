package com.example.appautenticao;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.appautenticao.databinding.ActivityMainBinding;
import com.example.appautenticao.databinding.ActivityRecuperaContaBinding;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {



    private Button button;

    private TextView textView;

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        button = button.findViewById(R.id.btnConsultar);
        textView = textView.findViewById(R.id.imageView);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Tarefa tarefa = new Tarefa();
                tarefa.execute("https://viacep.com.br/ws/01001000/json/");
            }
        });
    }
    private class Tarefa extends AsyncTask<String, String, String>{
        @Override
        protected String doInBackground(String... strings){
            String retorno = conexao.getDados(strings[0]);
            return retorno;
        }
        @Override
        protected void onPostExecute(String s){
            textView.setText(s);
        }

    }

}
