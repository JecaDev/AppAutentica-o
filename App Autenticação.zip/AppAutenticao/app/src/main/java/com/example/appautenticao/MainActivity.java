package com.example.appautenticao;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.appautenticao.databinding.ActivityMainBinding;


public class MainActivity extends AppCompatActivity {



    private Button button;

    private TextView textView;

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        button = (Button)findViewById(R.id.btnConsultar);
        textView = (TextView)findViewById(R.id.textView);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Tarefa tarefa = new Tarefa();
                tarefa.execute("https://viacep.com.br/ws/01001000/json/");
            }
        });
    }
    private class Tarefa extends AsyncTask<String, String, String>{
        @Override
        protected String doInBackground(String... strings){
            String retorno = conexao.getDados(strings[0]);
            return retorno;
        }
        @Override
        protected void onPostExecute(String s){
            textView.setText(s);
        }

    }

}
